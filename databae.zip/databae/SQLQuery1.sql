--CREATE DATABASE WaterHyacinth
USE WaterHyacinth

-- Create the satellite_images table
CREATE TABLE satellite_images (
    image_id INT PRIMARY KEY IDENTITY(1,1),
	image_name NVARCHAR(100),
    date_captured DATE NOT NULL,   
    location NVARCHAR(255) NOT NULL UNIQUE,  
    created_at DATETIME DEFAULT GETDATE(), 
    updated_at DATETIME DEFAULT GETDATE(), 
    source NVARCHAR(100) NOT NULL, 
	description NVARCHAR(1000),
);

